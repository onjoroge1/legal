import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  try {
    console.log('Starting questionnaire seeding...')

    // First, create categories
    console.log('Creating categories...')
    const businessCategory = await prisma.category.upsert({
      where: { id: 'business-formation' },
      update: {},
      create: {
        id: 'business-formation',
        name: 'Business Formation',
        slug: 'business-formation',
        description: 'Documents related to business formation and registration'
      }
    })

    const employmentCategory = await prisma.category.upsert({
      where: { id: 'employment' },
      update: {},
      create: {
        id: 'employment',
        name: 'Employment',
        slug: 'employment',
        description: 'Documents related to employment and HR'
      }
    })

    const ndaCategory = await prisma.category.upsert({
      where: { id: 'nda' },
      update: {},
      create: {
        id: 'nda',
        name: 'Non-Disclosure Agreements',
        slug: 'nda',
        description: 'Confidentiality and non-disclosure agreements'
      }
    })
    console.log('Categories created successfully')

    // Then create templates
    console.log('Creating document templates...')
    const businessFormationTemplate = await prisma.documentTemplate.upsert({
      where: { code: 'business-formation' },
      update: {},
      create: {
        code: 'business-formation',
        name: 'Business Formation Template',
        type: 'business',
        description: 'Template for business formation documents',
        categoryId: businessCategory.id,
        content: 'Business Formation Template Content',
        version: '1.0.0'
      }
    })

    const employmentAgreementTemplate = await prisma.documentTemplate.upsert({
      where: { code: 'employment-agreement' },
      update: {},
      create: {
        code: 'employment-agreement',
        name: 'Employment Agreement Template',
        type: 'employment',
        description: 'Template for employment agreement documents',
        categoryId: employmentCategory.id,
        content: 'Employment Agreement Template Content',
        version: '1.0.0'
      }
    })

    const ndaTemplate = await prisma.documentTemplate.upsert({
      where: { code: 'nda' },
      update: {},
      create: {
        code: 'nda',
        name: 'Non-Disclosure Agreement Template',
        type: 'nda',
        description: 'Template for non-disclosure agreement documents',
        categoryId: ndaCategory.id,
        content: 'NDA Template Content',
        version: '1.0.0'
      }
    })
    console.log('Document templates created successfully')

    // Finally create questionnaires
    console.log('Creating questionnaires...')
    // Business Formation Questionnaire
    await prisma.questionnaire.upsert({
      where: { id: 'business-formation-questionnaire' },
      update: {},
      create: {
        id: 'business-formation-questionnaire',
        name: 'Business Formation',
        description: 'Questionnaire for business formation documents',
        templateId: businessFormationTemplate.id,
        metadata: {
          category: businessCategory.id,
          type: 'business-formation'
        },
        questions: {
          create: [
            {
              label: 'Business Name',
              type: 'text',
              required: true,
              section: 'Basic Information',
              helpText: 'Enter the legal name of your business'
            },
            {
              label: 'Business Type',
              type: 'select',
              required: true,
              section: 'Basic Information',
              helpText: 'Select the type of business entity',
              options: {
                create: [
                  { value: 'llc', label: 'Limited Liability Company (LLC)' },
                  { value: 'corporation', label: 'Corporation' },
                  { value: 'partnership', label: 'Partnership' },
                  { value: 'sole_proprietorship', label: 'Sole Proprietorship' }
                ]
              }
            },
            {
              label: 'Business Address',
              type: 'text',
              required: true,
              section: 'Location',
              helpText: 'Enter the physical address of your business'
            },
            {
              label: 'Business Purpose',
              type: 'textarea',
              required: true,
              section: 'Business Details',
              helpText: 'Describe the primary purpose of your business'
            }
          ]
        }
      }
    })
    console.log('Created Business Formation questionnaire')

    // Employment Agreement Questionnaire
    await prisma.questionnaire.upsert({
      where: { id: 'employment-agreement-questionnaire' },
      update: {},
      create: {
        id: 'employment-agreement-questionnaire',
        name: 'Employment Agreement',
        description: 'Questionnaire for employment agreement documents',
        templateId: employmentAgreementTemplate.id,
        metadata: {
          category: employmentCategory.id,
          type: 'employment'
        },
        questions: {
          create: [
            {
              label: 'Employee Name',
              type: 'text',
              required: true,
              section: 'Employee Information',
              helpText: 'Enter the full name of the employee'
            },
            {
              label: 'Position',
              type: 'text',
              required: true,
              section: 'Employment Details',
              helpText: 'Enter the job position'
            },
            {
              label: 'Start Date',
              type: 'date',
              required: true,
              section: 'Employment Details',
              helpText: 'Enter the employment start date'
            },
            {
              label: 'Salary',
              type: 'number',
              required: true,
              section: 'Compensation',
              helpText: 'Enter the annual salary'
            },
            {
              label: 'Benefits',
              type: 'multiselect',
              required: false,
              section: 'Compensation',
              helpText: 'Select applicable benefits',
              options: {
                create: [
                  { value: 'health_insurance', label: 'Health Insurance' },
                  { value: 'dental_insurance', label: 'Dental Insurance' },
                  { value: 'vision_insurance', label: 'Vision Insurance' },
                  { value: '401k', label: '401(k) Retirement Plan' },
                  { value: 'pto', label: 'Paid Time Off' }
                ]
              }
            }
          ]
        }
      }
    })
    console.log('Created Employment Agreement questionnaire')

    // Non-Disclosure Agreement Questionnaire
    await prisma.questionnaire.upsert({
      where: { id: 'nda-questionnaire' },
      update: {},
      create: {
        id: 'nda-questionnaire',
        name: 'Non-Disclosure Agreement',
        description: 'Questionnaire for non-disclosure agreement documents',
        templateId: ndaTemplate.id,
        metadata: {
          category: ndaCategory.id,
          type: 'nda'
        },
        questions: {
          create: [
            {
              label: 'Disclosing Party',
              type: 'text',
              required: true,
              section: 'Parties',
              helpText: 'Enter the name of the party disclosing confidential information'
            },
            {
              label: 'Receiving Party',
              type: 'text',
              required: true,
              section: 'Parties',
              helpText: 'Enter the name of the party receiving confidential information'
            },
            {
              label: 'Confidential Information',
              type: 'textarea',
              required: true,
              section: 'Agreement Details',
              helpText: 'Describe the confidential information to be protected'
            },
            {
              label: 'Duration',
              type: 'select',
              required: true,
              section: 'Agreement Details',
              helpText: 'Select the duration of the confidentiality obligation',
              options: {
                create: [
                  { value: '1_year', label: '1 Year' },
                  { value: '2_years', label: '2 Years' },
                  { value: '3_years', label: '3 Years' },
                  { value: '5_years', label: '5 Years' },
                  { value: 'perpetual', label: 'Perpetual' }
                ]
              }
            }
          ]
        }
      }
    })
    console.log('Created Non-Disclosure Agreement questionnaire')

    // Employee Privacy Policy Template
    const employeePrivacyTemplate = await prisma.documentTemplate.upsert({
      where: { code: 'employee-privacy-policy' },
      update: {},
      create: {
        code: 'employee-privacy-policy',
        name: 'Employee Privacy Policy Template',
        type: 'employment',
        description: 'Template for employee privacy policy documents',
        categoryId: employmentCategory.id,
        content: 'Employee Privacy Policy Template Content',
        version: '1.0.0'
      }
    })
    console.log('Created Employee Privacy Policy template')

    // Employee Privacy Policy Questionnaire
    await prisma.questionnaire.upsert({
      where: { id: 'employee-privacy-policy-questionnaire' },
      update: {},
      create: {
        id: 'employee-privacy-policy-questionnaire',
        name: 'Employee Privacy Policy',
        description: 'Questionnaire for employee privacy policy documents',
        templateId: employeePrivacyTemplate.id,
        metadata: {
          category: employmentCategory.id,
          type: 'employment'
        },
        questions: {
          create: [
            {
              label: 'Company Name',
              type: 'text',
              required: true,
              section: 'Basic Information',
              helpText: 'Enter the legal name of the company'
            },
            {
              label: 'Types of Personal Information Collected',
              type: 'multiselect',
              required: true,
              section: 'Information Collection',
              helpText: 'Select the types of personal information collected from employees',
              options: {
                create: [
                  { value: 'personal_details', label: 'Personal Details (name, address, etc.)' },
                  { value: 'contact_info', label: 'Contact Information' },
                  { value: 'employment_history', label: 'Employment History' },
                  { value: 'education', label: 'Education Information' },
                  { value: 'financial_info', label: 'Financial Information' },
                  { value: 'health_info', label: 'Health Information' },
                  { value: 'performance_data', label: 'Performance Data' },
                  { value: 'disciplinary_records', label: 'Disciplinary Records' }
                ]
              }
            },
            {
              label: 'Information Collection Methods',
              type: 'multiselect',
              required: true,
              section: 'Information Collection',
              helpText: 'Select how employee personal information is collected',
              options: {
                create: [
                  { value: 'application_forms', label: 'Application Forms' },
                  { value: 'interviews', label: 'Interviews' },
                  { value: 'background_checks', label: 'Background Checks' },
                  { value: 'performance_reviews', label: 'Performance Reviews' },
                  { value: 'surveys', label: 'Surveys' },
                  { value: 'monitoring_systems', label: 'Monitoring Systems' }
                ]
              }
            },
            {
              label: 'Purpose of Information Collection',
              type: 'textarea',
              required: true,
              section: 'Information Collection',
              helpText: 'Describe the purpose for collecting employee personal information'
            },
            {
              label: 'Information Usage',
              type: 'textarea',
              required: true,
              section: 'Information Usage',
              helpText: 'Describe how employee personal information is used'
            },
            {
              label: 'Internal Access',
              type: 'multiselect',
              required: true,
              section: 'Access and Sharing',
              helpText: 'Select who has access to employee information within the company',
              options: {
                create: [
                  { value: 'hr_department', label: 'HR Department' },
                  { value: 'management', label: 'Management' },
                  { value: 'it_department', label: 'IT Department' },
                  { value: 'legal_department', label: 'Legal Department' },
                  { value: 'payroll_department', label: 'Payroll Department' }
                ]
              }
            },
            {
              label: 'Third-Party Sharing Circumstances',
              type: 'textarea',
              required: true,
              section: 'Access and Sharing',
              helpText: 'Describe when employee information might be shared with third parties'
            },
            {
              label: 'Information Retention Period',
              type: 'text',
              required: true,
              section: 'Data Management',
              helpText: 'Specify how long employee personal information is retained'
            },
            {
              label: 'Security Measures',
              type: 'textarea',
              required: true,
              section: 'Data Management',
              helpText: 'Describe the security measures in place to protect employee information'
            },
            {
              label: 'Email Monitoring Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on email monitoring'
            },
            {
              label: 'Internet Usage Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on internet usage monitoring'
            },
            {
              label: 'Telephone/Voicemail Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on telephone/voicemail monitoring'
            },
            {
              label: 'Video Surveillance Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on video surveillance'
            },
            {
              label: 'Location Tracking Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on GPS or location tracking'
            },
            {
              label: 'Biometric Data Policy',
              type: 'textarea',
              required: true,
              section: 'Monitoring Policies',
              helpText: 'Describe the company\'s policy on biometric data collection'
            },
            {
              label: 'Drug Testing Policy',
              type: 'textarea',
              required: true,
              section: 'Additional Policies',
              helpText: 'Describe the company\'s policy on drug testing'
            },
            {
              label: 'Background Check Policy',
              type: 'textarea',
              required: true,
              section: 'Additional Policies',
              helpText: 'Describe the company\'s policy on background checks'
            },
            {
              label: 'Personnel File Access',
              type: 'textarea',
              required: true,
              section: 'Employee Rights',
              helpText: 'Describe what access employees have to their personnel files'
            },
            {
              label: 'Information Correction Process',
              type: 'textarea',
              required: true,
              section: 'Employee Rights',
              helpText: 'Describe how employees can request corrections to their personal information'
            },
            {
              label: 'Privacy Concern Reporting',
              type: 'textarea',
              required: true,
              section: 'Employee Rights',
              helpText: 'Describe the procedure for reporting privacy concerns or violations'
            },
            {
              label: 'Privacy Oversight',
              type: 'text',
              required: true,
              section: 'Policy Management',
              helpText: 'Specify who is responsible for overseeing employee privacy'
            },
            {
              label: 'Policy Change Notification',
              type: 'textarea',
              required: true,
              section: 'Policy Management',
              helpText: 'Describe how employees will be notified of changes to the privacy policy'
            },
            {
              label: 'Policy Violation Consequences',
              type: 'textarea',
              required: true,
              section: 'Policy Management',
              helpText: 'Describe the consequences for violating the employee privacy policy'
            },
            {
              label: 'Sensitive Information Provisions',
              type: 'textarea',
              required: true,
              section: 'Compliance',
              helpText: 'Describe special provisions that apply for sensitive personal information'
            },
            {
              label: 'Privacy Law Compliance',
              type: 'multiselect',
              required: true,
              section: 'Compliance',
              helpText: 'Select which privacy laws the policy complies with',
              options: {
                create: [
                  { value: 'gdpr', label: 'General Data Protection Regulation (GDPR)' },
                  { value: 'ccpa', label: 'California Consumer Privacy Act (CCPA)' },
                  { value: 'hipaa', label: 'Health Insurance Portability and Accountability Act (HIPAA)' },
                  { value: 'ferpa', label: 'Family Educational Rights and Privacy Act (FERPA)' },
                  { value: 'other', label: 'Other Privacy Laws' }
                ]
              }
            }
          ]
        }
      }
    })
    console.log('Created Employee Privacy Policy questionnaire')

    console.log('Questionnaire seeding completed successfully!')
  } catch (error) {
    console.error('Error seeding questionnaires:', error)
    if (error.code === 'P2002') {
      console.error('Unique constraint violation. This record already exists.')
    }
  } finally {
    await prisma.$disconnect()
  }
}

main() 