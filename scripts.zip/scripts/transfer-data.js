﻿const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    try {
        // Transfer Users
        const users = await prisma.user.findMany();
        console.log(Migrating  users...);
        for (const user of users) {
            await prisma.user.create({ data: user });
        }

        // Transfer Categories
        const categories = await prisma.category.findMany();
        console.log(Migrating  categories...);
        for (const category of categories) {
            await prisma.category.create({ data: category });
        }

        // Transfer Templates
        const templates = await prisma.documentTemplate.findMany();
        console.log(Migrating  templates...);
        for (const template of templates) {
            await prisma.documentTemplate.create({ data: template });
        }

        // Transfer Documents
        const documents = await prisma.document.findMany();
        console.log(Migrating  documents...);
        for (const document of documents) {
            await prisma.document.create({ data: document });
        }

        // Transfer other related data...
        console.log('Migration completed successfully!');
    } catch (error) {
        console.error('Migration failed:', error);
        process.exit(1);
    } finally {
        await prisma.();
    }
}

main();
