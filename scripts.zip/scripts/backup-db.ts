import { PrismaClient } from '@prisma/client'
import * as fs from 'fs'
import * as path from 'path'

const prisma = new PrismaClient()

async function backupDatabase() {
  try {
    console.log('Starting database backup...')
    
    // Create backups directory if it doesn't exist
    const backupsDir = path.join(process.cwd(), 'prisma', 'backups')
    if (!fs.existsSync(backupsDir)) {
      fs.mkdirSync(backupsDir, { recursive: true })
    }

    // Get current timestamp for filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const backupFile = path.join(backupsDir, `backup-${timestamp}.json`)

    // Fetch all data from the database
    const data = {
      users: await prisma.user.findMany(),
      categories: await prisma.category.findMany(),
      documentTemplates: await prisma.documentTemplate.findMany(),
      templateFields: await prisma.templateField.findMany(),
      questionnaires: await prisma.questionnaire.findMany(),
      questions: await prisma.question.findMany(),
      questionOptions: await prisma.questionOption.findMany(),
      questionDependencies: await prisma.questionDependency.findMany(),
    }

    // Write data to backup file
    fs.writeFileSync(backupFile, JSON.stringify(data, null, 2))
    console.log(`Backup completed successfully: ${backupFile}`)

    // Keep only the last 7 days of backups
    const files = fs.readdirSync(backupsDir)
    const backupFiles = files.filter(file => file.startsWith('backup-') && file.endsWith('.json'))
    backupFiles.sort().reverse()

    if (backupFiles.length > 7) {
      const filesToDelete = backupFiles.slice(7)
      for (const file of filesToDelete) {
        fs.unlinkSync(path.join(backupsDir, file))
        console.log(`Deleted old backup: ${file}`)
      }
    }

  } catch (error) {
    console.error('Error during backup:', error)
  } finally {
    await prisma.$disconnect()
  }
}

// Run the backup
backupDatabase() 