# Efficient Database Migration Script for Neon
# This script handles direct migration from SQLite to Neon PostgreSQL

# Store the original DATABASE_URL
$SQLITE_URL = "file:./dev.db"
$NEON_URL = "postgresql://neondb_owner:npg_A3BZzngtwQv1@ep-restless-base-a4y7to0l-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require"

# Backup the original schema.prisma
Write-Host "Backing up original schema..."
Copy-Item "prisma/schema.prisma" "prisma/schema.prisma.backup"

# Update schema.prisma to use PostgreSQL
Write-Host "Updating schema for PostgreSQL..."
$schemaContent = Get-Content "prisma/schema.prisma"
$schemaContent = $schemaContent -replace 'provider = "sqlite"', 'provider = "postgresql"'
$schemaContent | Set-Content "prisma/schema.prisma"

# Set environment variable for Neon
$env:DATABASE_URL = $NEON_URL

# Generate Prisma Client with new schema
Write-Host "Generating Prisma Client..."
npx prisma generate

# Push the schema to Neon
Write-Host "Pushing schema to Neon..."
npx prisma db push --accept-data-loss

# Create migration script for data transfer
Write-Host "Creating migration script..."
@"
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    try {
        // Transfer Users
        const users = await prisma.user.findMany();
        console.log(`Migrating ${users.length} users...`);
        for (const user of users) {
            await prisma.user.create({ data: user });
        }

        // Transfer Categories
        const categories = await prisma.category.findMany();
        console.log(`Migrating ${categories.length} categories...`);
        for (const category of categories) {
            await prisma.category.create({ data: category });
        }

        // Transfer Templates
        const templates = await prisma.documentTemplate.findMany();
        console.log(`Migrating ${templates.length} templates...`);
        for (const template of templates) {
            await prisma.documentTemplate.create({ data: template });
        }

        // Transfer Documents
        const documents = await prisma.document.findMany();
        console.log(`Migrating ${documents.length} documents...`);
        for (const document of documents) {
            await prisma.document.create({ data: document });
        }

        // Transfer other related data...
        console.log('Migration completed successfully!');
    } catch (error) {
        console.error('Migration failed:', error);
        process.exit(1);
    } finally {
        await prisma.$disconnect();
    }
}

main();
"@ | Out-File -FilePath "scripts/transfer-data.js" -Encoding UTF8

# Run the migration script
Write-Host "Transferring data..."
node scripts/transfer-data.js

# Restore original schema
Write-Host "Restoring original schema..."
Move-Item "prisma/schema.prisma.backup" "prisma/schema.prisma" -Force

Write-Host "Migration completed! Please verify the data in Neon." 