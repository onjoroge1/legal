import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  try {
    console.log('Checking database connection...')
    
    // Check users
    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
      },
    })
    console.log('Users:', users)
    
    // Check documents
    const documents = await prisma.document.findMany({
      select: {
        id: true,
        title: true,
        userId: true,
      },
    })
    console.log('Documents:', documents)
    
  } catch (error) {
    console.error('Error checking database:', error)
  } finally {
    await prisma.$disconnect()
  }
}

main() 